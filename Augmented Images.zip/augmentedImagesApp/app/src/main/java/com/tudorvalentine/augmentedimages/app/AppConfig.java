package com.tudorvalentine.augmentedimages.app;

public class AppConfig {
    private static boolean local = true;
    public static final String URL_REGISTER = local ? "http://192.168.8.117:8080/app/register" : "https://augmented-images.herokuapp.com/app/register" ;
    public static final String URL_AUTH = local ? "http://192.168.8.117:8080/app/login" : "https://augmented-images.herokuapp.com/app/login";
    public static final String URL_IMAGES = local ? "http://192.168.8.117:8080/app/images" : "https://augmented-images.herokuapp.com/app/images";
    public static final String URL_PDF = local ? "http://192.168.8.117:8080/app/pdf/" : "https://augmented-images.herokuapp.com/app/pdf/";
    public static final String URL_SYNC = local ? "http://192.168.8.117:8080/app/sync/" : "https://augmented-images.herokuapp.com/app/sync/";
}
